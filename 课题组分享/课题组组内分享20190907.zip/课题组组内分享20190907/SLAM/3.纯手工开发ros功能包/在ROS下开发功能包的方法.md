### 在ROS下开发功能包的方法

来源于创客智造CKZZhttps://www.ncnynl.com/archives/201701/1273.html



一 安装QT工具

1 简介

​      Qt是跨平台C++[图形用户界面应用程序开发框架。它既可以开发GUI程序，也可用于开发非GUI程序，比如控制台工具和服务器。Qt是面向对象的框架，使用特殊的代码生成扩展（称为元对象编译器(Meta Object Compiler, moc)）以及一些宏，Qt很容易扩展，并且允许真正地组件编程。

2 下载并安装QT

1）下载

```
wget http://download.qt.io/archive/qt/5.8/5.8.0/qt-opensource-linux-x64-5.8.0.run
```

注意，下载完成后，直接双击安装包是没有用的！需要先取得权限才行！！！

2）取得权限

进入安装包所在的文件夹，打开终端，输入以下代码即可：

```
https://www.ncnynl.com/archives/201701/1273.htmlchmod +x 安装包的全称
```

我这里是输入的是：

```
sudo chmod +x qt-opensource-linux-x64-5.8.0.run
```

3）安装QT

取得权限后，双击安装包即可开始安装。其中需要输入QT帐号，注册机即可，其他全部默认设置安装。

4）安装ros_qtc_plugin插件（Ubuntu16.04）

```
sudo add-apt-repository ppa:levi-armstrong/qt-libraries-xenial
sudo add-apt-repository ppa:levi-armstrong/ppa
sudo apt-get update && sudo apt-get install qt57creator-plugin-ros libqtermwidget57-0-dev
```

5）修改系统配置文件让Qt启动器选择新版的Qt

```
 sudo gedit /usr/lib/x86_64-linux-gnu/qt-default/qtchooser/default.conf
```

打开后，把两行内容修改成：

```
/home/ubu/Qt5.8.0/5.8/gcc_64/bin
/home/ubu/Qt5.8.0/5.8/gcc_64/lib
```

/home/ubu是我的主文件夹绝对路径，请对应修改为自己的。